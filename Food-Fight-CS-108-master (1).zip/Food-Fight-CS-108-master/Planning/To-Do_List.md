# To-Do

All tasks that need to be completed will be listed here.

## Project Stats

* Version: 0.1a (Pre-Alpha)


----------

# Code

## New Features

* Add a Splash Screen (new Scene File)
* Add a Level Screen (new Scene File)
* Create Unit node/scene and Unit Class Files
* Create Grid Class Files

## Bugs

* Any bugs go here

### Resolved

* All resolved bugs go here


----------

# Art Assets

## Graphics

* Logo

## Music

### Title Theme

* Initial Theme Design

### Level Theme

* Initial Theme Design

